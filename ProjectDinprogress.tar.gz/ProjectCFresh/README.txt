Jesse Cooper
Jean Prinston
Trey Darling

All of C is working without errors,
Shell code needs to be cleaned up a bit and made slightly better.

The program is set up to run shell.


