//shell.c


main()
{

	char string[25];
	char filename[6];
	char buffer[13312];
	int sector;
	char shell[7];
	char type[5];
	char exec[5];
	char dir[4];
	char del[4];
	int i;
	int j;

//	syscall(0,"before shell");
	shell[0]='s';
	shell[1]='h';
	shell[2]='e';
	shell[3]='l';
	shell[4]='l';
	shell[5]='>';
	shell[6]='\0';
//	syscall(0,"before type");
	type[0]='t';
	type[1]='y';
	type[2]='p';
	type[3]='e';
	type[4]='\0';
//	syscall(0,"before exec");
	exec[0]='e';
	exec[1]='x';
	exec[2]='e';
	exec[3]='c';
	exec[4]='\0';
//	syscall(0,"before dir");
	dir[0]='d';
	dir[1]='i';
	dir[2]='r';
	dir[3]='\0';
	
	del[0]='d';
	del[1]='e';
	del[2]='l';
	del[3]='\0';

	while(1){



		syscall(0,shell);

		syscall(1,string);


		if (string[0]==type[0] && string[1]==type[1] && string[2]==type[2] && string[3]==type[3]) 
		{
	//	syscall(0,"in if");
			filename[0]=string[5];
			filename[1]=string[6];
			filename[2]=string[7];
			filename[3]=string[8];
			filename[4]=string[9];
			filename[5]=string[10];

	//	syscall(0,filename);
			syscall(3,buffer,filename,&sector);

			if (sector>0) 
			{
				syscall(0,buffer);
				syscall(0,"\r\n");
				sector--;

			} else
				{
				syscall(0,"file not found\r\n");
				}

		}

		else if (string[0]==exec[0] && string[1]==exec[1] && string[2]==exec[2] && string[3]==exec[3])  

		{
        //      syscall(0,"in if");
               		 filename[0]=string[5];
               		 filename[1]=string[6];
              		  filename[2]=string[7];
              		  filename[3]=string[8];
               		 filename[4]=string[9];
               		 filename[5]=string[10];

        //      syscall(0,filename);
               		 syscall(3,buffer,filename,&sector);



                if (sector>0) {
                        syscall(4,filename);
                        syscall(0,"\r\n");
                        sector--;

                                } else {

                syscall(0,"file not found\r\n");

	        }

		} else if (string[0]==dir[0] && string[1]==dir[1] && string[2]==dir[2]) { 

		syscall(2,&buffer,2);
		syscall(0,"Directory:\r\n");
		for(i=0;i<512;i+=32){
		//if first letter is  not null we will assume it is a filename.
		if(buffer[i] != '\0'){
		filename[0]=buffer[i];
		filename[1]=buffer[i+1];
		filename[2]=buffer[i+2];
		filename[3]=buffer[i+3];
		filename[4]=buffer[i+4];
		filename[5]=buffer[i+5];
		filename[6]='\0';
		syscall(0,filename);
		syscall(0,"\r\n");
		}
		}
	//	for(i=0;i<=512;i++){
//
//			if(buffer[i] >= 'a' && buffer[i] <= 'z'){
//			syscall(0,buffer[i]);
//			}
//		}

		} else if (string[0]==del[0] && string[1]==del[1] && string[2]==del[2]) {
		
			filename[0]=string[4];
			filename[1]=string[5];
			filename[2]=string[6];
			filename[3]=string[7];
			filename[4]=string[8];
			filename[5]=string[9];	
	
			syscall(7,filename);
	
	
	         	} else {

			syscall(0,"Error!\r\n");

			}


	}
}






