//shell.c

//Jesse Cooper
//Trey Darling
//Jean Prinston

main()
{

	char string[25];
	char filename[7];
	char newfilename[7];
	char buffer[13312];
	int sector;
	int sectorsread;
	char shell[7];
	char type[5];
	char exec[5];
	char dir[4];
	char del[4];
	char copy[4];
	char cf[13];
	int endpoint;
	int i;
	int j;

//	syscall(0,"before shell");
	shell[0]='s';
	shell[1]='h';
	shell[2]='e';
	shell[3]='l';
	shell[4]='l';
	shell[5]='>';
	shell[6]='\0';
//	syscall(0,"before type");
	type[0]='t';
	type[1]='y';
	type[2]='p';
	type[3]='e';
	type[4]='\0';
//	syscall(0,"before exec");
	exec[0]='e';
	exec[1]='x';
	exec[2]='e';
	exec[3]='c';
	exec[4]='\0';
//	syscall(0,"before dir");
	dir[0]='d';
	dir[1]='i';
	dir[2]='r';
	dir[3]='\0';
	
	del[0]='d';
	del[1]='e';
	del[2]='l';
	del[3]='\0';

	copy[0]='c';
	copy[1]='o';
	copy[2]='p';
	copy[3]='y';

	cf[0]='c';
	cf[1]='r';
	cf[2]='e';
	cf[3]='a';
	cf[4]='t';
	cf[5]='e';
	cf[6]=' ';
	cf[7]='t';
	cf[8]='e';
	cf[9]='x';
	cf[10]='t';
	cf[11]='f';
	cf[12]='l';
	
	while(1){



		syscall(0,shell);

		syscall(1,string);


		if (string[0]==type[0] && string[1]==type[1] && string[2]==type[2] && string[3]==type[3]) 
		{
	//	syscall(0,"in if");
			filename[0]=string[5];
			filename[1]=string[6];
			filename[2]=string[7];
			filename[3]=string[8];
			filename[4]=string[9];
			filename[5]=string[10];

	//	syscall(0,filename);
			syscall(3,buffer,filename,&sector);

			if (sector>0) 
			{
				syscall(0,buffer);
				syscall(0,"\r\n");
				sector--;

			} else
				{
				syscall(0,"file not found\r\n");
				}

		}

		else if (string[0]==exec[0] && string[1]==exec[1] && string[2]==exec[2] && string[3]==exec[3])  

		{
        //      syscall(0,"in if");
               		 filename[0]=string[5];
               		 filename[1]=string[6];
              		  filename[2]=string[7];
              		  filename[3]=string[8];
               		 filename[4]=string[9];
               		 filename[5]=string[10];

        //      syscall(0,filename);
               		 syscall(3,buffer,filename,&sector);



                if (sector>0) {
                        syscall(4,filename);
                        syscall(0,"\r\n");
                        sector--;

                                } else {

                syscall(0,"file not found\r\n");

	        }

		} else if (string[0]==dir[0] && string[1]==dir[1] && string[2]==dir[2]) { 

		syscall(2,&buffer,2);
		syscall(0,"Directory:\r\n");
		for(i=0;i<512;i+=32){
		if(buffer[i] != '\0' && buffer[i] != ' '){
		filename[0]=buffer[i];
		filename[1]=buffer[i+1];
		filename[2]=buffer[i+2];
		filename[3]=buffer[i+3];
		filename[4]=buffer[i+4];
		filename[5]=buffer[i+5];
		filename[6]='\0';
		syscall(0,filename);
		syscall(0,"\r\n");
		}
		}
	//	for(i=0;i<=512;i++){
//
//			if(buffer[i] >= 'a' && buffer[i] <= 'z'){
//			syscall(0,buffer[i]);
//			}
//		}

		} else if (string[0]==del[0] && string[1]==del[1] && string[2]==del[2]) {
		
			filename[0]=string[4];
			filename[1]=string[5];
			filename[2]=string[6];
			filename[3]=string[7];
			filename[4]=string[8];
			filename[5]=string[9];	
	
			syscall(7,filename);
	
	
	         	}
		
		else if (string[0]==copy[0] && string[1]==copy[1] && string[2]==copy[2] && string[3]==copy[3]) {
			for(i=0;i<=6;i++) filename[i]='\0';
			for(i=0;i<=6;i++) newfilename[i]='\0';
			
			j=0;
			
			for(i=5;i<=11;i++){
			endpoint=i;
			if(string[i]==' '){ break;}
			
			filename[j]=string[i];
			j++;

			}

			j=0;

			for(i=endpoint+1;i<=endpoint+6;i++){
			if(string[i]==' '){ break;} 
			newfilename[j]=string[i];
			j++;
			}
			syscall(0,"READING:");
			syscall(0,filename);
			syscall(0,"WRITING:");
			syscall(0,newfilename);
			sectorsread=0;
			
			for(i=0;i<13312;i++) {buffer[i]='\0';}
			
			syscall(3,buffer,filename,&sectorsread);
			
			syscall(8,buffer,newfilename,sectorsread);

			} else if(string[0]==cf[0] && string[1]==cf[1] && string[2]==cf[2] && string[3]==cf[3] && string[4]==cf[4] && string[5]==cf[5] && string[6]==cf[6] && string[7]==cf[7] && string[8]==cf[8] && string[9]==cf[9] && string[10]==cf[10] && string[11]==cf[11] && string[12]==cf[12]){
			for(i=0;i<13312;i++) {buffer[i]='\0';}
			j=0;
			
			while(1) {
				syscall(1,string);
				i=0;
				if(string[0]==' '){
				syscall(8,buffer,"textfl",1);
				break;
			}
				while(string[i] != '\0'){
				buffer[i+j]=string[i];
				
				i++;	
			} 
			//	buffer[i+j]='\r';
			//	i++;
			//	buffer[i+j]='\n';
			//	i++;
				j+=i;
			}
			


			}else {

			syscall(0,"Error!\r\n");

			}


	}
}






