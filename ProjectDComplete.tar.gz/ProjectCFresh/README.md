# COMP350_ProjectD

We have completed Project D

Everything should work, maybe not perfectly at all times.

Everything should be testable.

