
//kernel.c
//Jean Prinston, 2023

void printString(char*);
void printChar(char c);
void readString(char*);
void readSector(char* buffer, int sector);
void handleInterrupt21(int ax, int bx, int cx, int dx);
void readFile(char*, char*, int*);
void executeProgram(char*);
void terminate();
void shell();
void writeSector(char* buffer, int sector);
void deleteFile(char* filename);
void writeFile(char*,char*,int);

void main() {
	
//	int startVidMem = 0xb800;
//	int vidMemOffset = 0x0;
//	int white = 0x7;
//	char* letters = "Hello World\0";

//	char buffer[13312];   /*this is the maximum size of a file*/
//	int sectorsRead;
//	makeInterrupt21(); 
//	interrupt(0x21, 3, buffer,  "messag", &sectorsRead);   /*read the file into buffer*/ 
//	if (sectorsRead>0) {
//		interrupt(0x21, 0, buffer, 0, 0);   /*print out the file*/ 
//	} else {
//		interrupt(0x21, 0, "messag not found\r\n", 0, 0);  /*no sectors read? then print an error*/
//	} 

	makeInterrupt21();
	interrupt(0x21,8,"this is a test message","testmg",3);
	
	interrupt(0x21,5,0,0);
//	interrupt(0x21,5,0,0);
//	printString("HELLO!");
	while(1);   /*hang up*/ 

}

void printString(char* chars) {

	while(*chars != 0x0) {
		char al = *chars;
		char ah = 0xe;
		int ax = ah*256 + al;
		interrupt(0x10, ax, 0, 0, 0);
		chars++;
	}
}

void printChar(char c) {
	
	interrupt(0x10, 0xe*256+c, 0, 0, 0);
}

void readString (char* chars) {
	
	char l;
	int i=0;
	char space = ' ';

	while(1) {
	
		l = interrupt(0x16, 0, 0, 0, 0);

		if (l == 0x8 && i > 0) {

			interrupt(0x10, 0xe*256 + l, 0, 0, 0);
			interrupt(0x10, 0xe*256 + space, 0, 0, 0);
			interrupt(0x10, 0xe*256 + l, 0, 0, 0);
			chars[i] = ' ';
			i--;
		}
		else if (l == 0x8 && i == 0) {
		}
		else if (l == 0xd) {
			interrupt(0x10, 0xe*256+l, 0, 0, 0);
			chars[i] = l;
			i++;
			chars[i] = 0xa;
			interrupt(0x10, 0xe*256+chars[i], 0, 0, 0);
			i++;
			chars[i] = 0x0;
			interrupt(0x10, 0xe*256+chars[i], 0, 0, 0);
			return;
		}
		else {
			interrupt(0x10, 0xe*256+l, 0, 0, 0);
			chars[i] = l;
			i++;
		}
	}
}

void readSector(char* buffer, int sector) {

	//char l;
	int ah = 2;
	int al = 1;
	int bx = buffer;
	int ch = 0;
	int cl = sector+1;
	int dh = 0;
	int dl = 0x80;
	int ax = ah*256 + al;
	int cx = ch*256 + cl;
	int dx = dh*256 + dl;
	interrupt(0x13, ax, bx, cx, dx);

}

void writeSector(char* buffer, int sector) {

	int ah = 3;
	int al = 1;
	int bx = buffer;
	int ch = 0;
	int cl = sector+1;
	int dh = 0;
	int dl = 0x80;
	int ax = ah*256 + al;
	int cx = ch*256 + cl;
	int dx = dh*256 + dl;
	interrupt(0x13, ax, bx, cx, dx);

}

void handleInterrupt21(int ax, int bx, int cx, int dx) {

	//printString("Hello world");

	if (ax == 0) {
		printString(bx);
	} else if (ax == 1) {
		readString(bx);
	} else if (ax == 2) {
		readSector(bx, cx);
	}else if (ax == 3) {
		readFile(bx, cx, dx); 
	} else if (ax == 4) {
		executeProgram(bx);
	} else if (ax == 5) {
		terminate();
//	} else if (ax == 6) { 
//		executeProgram("shell");
	} else if (ax == 6) {
		writeSector(bx, cx);
       } else if (ax == 7) {
		deleteFile(bx);
	} else if (ax == 8) {
		writeFile(bx, cx, dx);
	} else {
		printString("Error!");
	}
}

void readFile(char* buffer, char* fileName, int* sectorsRead) {

	char dir[512];
	int i=6;
	int j=0;
	int fileentry;
	readSector(dir, 2);


	for (fileentry = 0; fileentry <= 512; fileentry += 32) {
		if (fileName[0]==dir[fileentry+0] && fileName[1]==dir[fileentry+1] && fileName[2]==dir[fileentry+2] && fileName[3]==dir[fileentry+3] && fileName[4]==dir[fileentry+4] && fileName[5]==dir[fileentry+5]) {
			//printString("Found the file!");

			while (dir[fileentry+i] != 0) {
				readSector(buffer+j, dir[fileentry+i]);
				i += 1;
				j += 512;
				(*sectorsRead)++;

			}
		}

	}
}

void executeProgram(char* name) 
{

	char buffer[13312];
	int sectorsRead;
	int segment=0x2000;
	int i;

	readFile(buffer,name,&sectorsRead);

	for(i=0;i<=13312;i++){
	putInMemory(segment,i,buffer[i]); //segment,address,character
	}

	launchProgram(segment);

}

void terminate()
{

char shellname[6];

shellname[0]='s';
shellname[1]='h';
shellname[2]='e';
shellname[3]='l';
shellname[4]='l';
shellname[5]='\0';

executeProgram(shellname);

//while(1);

}

void deleteFile(char* filename)
{

char map[512];
char dir[512];
char sectorToZero;
int i;

readSector(map,1);
readSector(dir,2);

for(i=0;i<512;i++){

if(dir[i]==filename[0] && dir[i+1]==filename[1] && dir[i+2]==filename[2] && dir[i+3]==filename[3] && dir[i+4]==filename[4] && dir[i+5]==filename[5]){

dir[i]='\0';

while(dir[i+6] != '\0'){
sectorToZero=dir[i+6];
map[sectorToZero]='\0';
i++;

}

}

}

writeSector(map,1);
writeSector(dir,2);

}

void writeFile(char* buffer, char* filename, int numberOfSectors)
{
char map[512];
char dir[512];
//int numberOfSectors;
int dirEntry;
int j;
int i;
int dirFlag;
int mapFlag;

readSector(map,1);
readSector(dir,2);

for(i=0;i<512;i+=32){
if(dir[i]=='\0' && dirFlag==0){
dir[i]=filename[0];
dir[i+1]=filename[1];
dir[i+2]=filename[2];
dir[i+3]=filename[3];
dir[i+4]=filename[4];
dir[i+5]=filename[5];
dirEntry=i+6;
dirFlag=1;
}

}

if(dirFlag==0) {return;}

for(i=3;i<512;i++){
if(map[i]=='\0'){
map[i]=0xFF;
dir[dirEntry]=i;
dirEntry++;
writeSector(buffer,i);
buffer+=512;
mapFlag=1;
numberOfSectors--;
} 
if(numberOfSectors==0) {break;}
}

if(mapFlag==0) {return;}

//for(j=6+numberOfSectors;j<32;j++){
//dir[j]='\0';
//}

writeSector(map,1);
writeSector(dir,2);

}



